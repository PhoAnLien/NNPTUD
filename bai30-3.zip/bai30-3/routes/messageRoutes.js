const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Message = require('../models/Message');

/**
 * 1. GET /:userID 
 * Lấy toàn bộ lịch sử nhắn tin giữa 2 người (Inbox chi tiết)
 */
router.get('/:userID', async (req, res) => {
  try {
    const { userID } = req.params;
    const currentUserID = req.user.id;

    const messages = await Message.find({
      $or: [
        { from: currentUserID, to: userID },
        { from: userID, to: currentUserID }
      ]
    }).sort({ createdAt: 1 }); // Xếp tin mới nhất ở dưới cùng

    res.status(200).json({ success: true, count: messages.length, data: messages });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * 2. POST / 
 * Gửi nội dung tin nhắn (Tự động nhận diện File hay Text)
 */
router.post('/', async (req, res) => {
  try {
    const { to, content, isFile } = req.body; // isFile: true/false
    const from = req.user.id;

    // Logic: Nếu là file thì type: 'file', ngược lại là 'text'
    const messageType = isFile ? 'file' : 'text';

    const newMessage = new Message({
      from,
      to,
      contentMessage: {
        type: messageType,
        content: content // URL nếu là file, Nội dung nếu là text
      }
    });

    await newMessage.save();
    res.status(201).json({ success: true, data: newMessage });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

/**
 * 3. GET / 
 * Lấy danh sách cuộc hội thoại (Tin nhắn cuối cùng với mỗi người)
 */
router.get('/', async (req, res) => {
  try {
    const currentUserID = new mongoose.Types.ObjectId(req.user.id);

    const conversations = await Message.aggregate([
      // Lọc tất cả tin nhắn của tôi
      {
        $match: {
          $or: [{ from: currentUserID }, { to: currentUserID }]
        }
      },
      // Sắp xếp giảm dần để tin mới nhất lên đầu
      { $sort: { createdAt: -1 } },
      // Xác định ID của đối phương (partner)
      {
        $addFields: {
          partnerID: {
            $cond: {
              if: { $eq: ['$from', currentUserID] },
              then: '$to',
              else: '$from'
            }
          }
        }
      },
      // Gom nhóm theo đối phương, lấy tin nhắn đầu tiên (chính là tin cuối cùng)
      {
        $group: {
          _id: '$partnerID',
          lastMessage: { $first: '$$ROOT' }
        }
      },
      // (TÙY CHỌN) Lấy thêm thông tin user từ collection 'User'
      /*
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'userInfo'
        }
      },
      { $unwind: '$userInfo' }
      */
    ]);

    res.status(200).json({ success: true, data: conversations });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
