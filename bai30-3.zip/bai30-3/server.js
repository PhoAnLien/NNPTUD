require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');
const messageRouter = require('./routes/messageRoutes');

const app = express();
app.use(express.json());

// Kết nối database
connectDB();

// Mock middleware giả lập user hiện tại (để test)
app.use((req, res, next) => {
  // Giả sử user đang đăng nhập có ID này
  req.user = { id: '65f1a2b3c4d5e6f7a8b9c0d1' }; 
  next();
});

// Sử dụng Routes
app.use('/api/messages', messageRouter);

const PORT = 5000;
app.listen(PORT, () => console.log(`Server chạy tại: http://localhost:${PORT}`));
