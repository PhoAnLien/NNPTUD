const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    // Ưu tiên dùng MONGO_URI trong .env, nếu không có thì dùng localhost
    const dbURI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/chat_database';
    const conn = await mongoose.connect(dbURI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
